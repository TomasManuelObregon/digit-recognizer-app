"""
@author: Tomás Obregón
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from skimage.transform import rotate


#%% 
df = pd.read_csv('/Users/tomas/Desktop/Number/mnist_train.csv')

labels = df.iloc[:, 0]
images = df.iloc[:, 1:].values

#%%
def show(dataset, new_dataset, i):
    image = dataset[i].reshape(28, 28)
    new_image = new_dataset[i].reshape(28, 28)
    
    plt.figure(figsize=(8, 4))
    
    # Primer subplot para la imagen original
    plt.subplot(1, 2, 1)
    plt.imshow(image, cmap='gray')
    plt.title(f'Etiqueta original: {labels[i]}')
    plt.axis('off')
    
    # Segundo subplot para la imagen modificada
    plt.subplot(1, 2, 2)
    plt.imshow(new_image, cmap='gray')
    plt.axis('off')
    
    plt.show()

def change(images):    
    new_images = []
    
    for image in images:
        image = image.reshape(28, 28)    
        
        # Rotate - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        theta = np.random.uniform(-20, 20)
        new_image = rotate(image, theta) 

        # Offset - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        offset_x = np.random.randint(-5, 5)
        offset_y = np.random.randint(-5, 5)
        
        new_image = np.roll(new_image, shift=offset_x, axis=1)
        new_image = np.roll(new_image, shift=offset_y, axis=0)
        
        # cut or fill
        if offset_x > 0:
            new_image[:, :offset_x] = 0  # Fill with zeros
        elif offset_x < 0:
            new_image[:, offset_x:] = 0
        
        if offset_y > 0:
            new_image[:offset_y, :] = 0  # Fill with zeros
        elif offset_y < 0:
            new_image[offset_y:, :] = 0
                
        # Normalize  - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
        new_image = (new_image/max(new_image.flatten()))*255 

        # Noice  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        noice = np.random.randint(0,30, size=(28, 28))
        new_image += noice
            
        #- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        new_images.append(new_image)
        
    new_images = np.array(new_images, dtype= np.int64).reshape(60000, 784)
    return new_images
        
new_images = change(images)


#%% 
# for i in range(100):
#     show(images,new_images, i)

#%%
# Crear un nuevo DataFrame con las etiquetas y las nuevas imágenes
new_df = pd.DataFrame(new_images)
new_df.insert(0, 'label', labels)  # Insertar las etiquetas en la primera columna

# Exportar el nuevo DataFrame a un archivo CSV
# new_df.to_csv('/Users/tomas/Desktop/Number/mnist_train_2.csv', index=False)


#%%

# Supongamos que df es tu DataFrame original
columnas = ['label'] + [f'{i}x{j}' for i in range(1, 29) for j in range(1, 29)]
new_df.columns = columnas

nmist_train_3 = pd.concat([new_df, df], axis=0)

nmist_train_3.to_csv('/Users/tomas/Desktop/Number/nmist_train_3.csv', index=False)

#%%






