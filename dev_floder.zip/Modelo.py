"""
@author: Tomás Obregón
"""

import torch
import torch.nn as nn
import pandas as pd
import matplotlib.pyplot as plt

#%%
df = pd.read_csv('/Users/tomas/Desktop/Number/nmist_train_3.csv')

# Convertir los datos a tensores
train_labels = torch.tensor(df.iloc[:, 0].values, dtype=torch.long)
train_images = torch.tensor(df.iloc[:, 1:].values, dtype=torch.float32)/255

#%%
# Definir el modelo
class Model(nn.Module):
    def __init__(self):
        super().__init__()
        self.l1       = nn.Linear(784, 256)  
        # self.bn1      = nn.BatchNorm1d(256)
        self.dropout1 = nn.Dropout(0.2)  
      
        self.l2       = nn.Linear(256, 128)   
        # self.bn2      = nn.BatchNorm1d(128)
        self.dropout2 = nn.Dropout(0.2)  
        
        self.l3 = nn.Linear(128, 10)   

        
    def forward(self, x):
        x = nn.functional.relu(self.l1(x))
        x = self.dropout1(x)  
        x = nn.functional.relu(self.l2(x))
        x = self.dropout2(x)  
        x = nn.functional.relu(self.l3(x))

        return x
    
# Crear el conjunto de datos y el DataLoader
train_dataset = torch.utils.data.TensorDataset(train_images, train_labels)
train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=64, shuffle=True)

# Instanciar el modelo, la función de pérdida y el optimizador
model = Model()
criterion = nn.CrossEntropyLoss()  # Esta es la función de pérdida correcta
optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

# Entrenamiento del modelo
num_epochs = 150
losses = []

for epoch in range(num_epochs):
    model.train()  # Poner el modelo en modo de entrenamiento
    running_loss = 0.0
    
    for inputs, labels in train_loader:
        optimizer.zero_grad()  # Limpiar los gradientes

        # Forward pass
        outputs = model(inputs)
        loss = criterion(outputs, labels)  # Calcular la pérdida correctamente
        
        # Backward pass y optimización
        loss.backward()
        optimizer.step()
        
        running_loss += loss.item()

    avg_loss = running_loss / len(train_loader)
    losses.append(avg_loss)
    
    # Imprimir la pérdida de la época actual
    print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {avg_loss:.4f}')

    plt.plot(figsize=[16,8])
    # Graficar la función de pérdida en tiempo real
    plt.clf()  # Limpiar la figura para la actualización en tiempo real
    plt.plot(losses, label='Loss', c='r')
    plt.xlabel('Epoch', fontsize=20)
    plt.ylabel('Loss', fontsize=20)
    plt.title('Loss over Epochs')
    plt.legend(fontsize=15)
    plt.grid(linestyle='--')
    plt.draw()
    plt.pause(0.1)  # Pausa para permitir la actualización de la gráfica

plt.show()  # Mostrar la gráfica final después del entrenamiento


#%%
# Save the model parameters
torch.save(model.state_dict(), 'model_parameters_2.pth')


# # Use this to load it 
# model.load_state_dict(torch.load('model_parameters.pth'))


#%% 

# Cargar los datos de prueba
test_df = pd.read_csv('/Users/tomas/Desktop/Number/mnist_test.csv')

# Convertir los datos de prueba a tensores
test_labels = torch.tensor(test_df.iloc[:, 0].values, dtype=torch.long)
test_images = torch.tensor(test_df.iloc[:, 1:].values, dtype=torch.float32)/255

# Crear el conjunto de datos y el DataLoader para los datos de prueba
test_dataset = torch.utils.data.TensorDataset(test_images, test_labels)
test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=100, shuffle=False)

# Poner el modelo en modo de evaluación
model.eval()

# Desactivar el cálculo de gradientes para la evaluación
with torch.no_grad():
    correct = 0
    total = 0
    
    for inputs, labels in test_loader:
        outputs = model(inputs)  # Realizar predicciones
        _, predicted = torch.max(outputs.data, 1)  # Obtener la clase con mayor probabilidad
        
        total += labels.size(0)
        correct += (predicted == labels).sum().item()  # Contar cuántas predicciones fueron correctas
    
    accuracy = 100 * correct / total
    print(f'Precisión del modelo en el conjunto de prueba: {accuracy:.2f}%')



#%% 
# Cargar el archivo CSV de la imagen
imagen_df = pd.read_csv('/mnt/data/imagen.csv')

# Convertir la imagen a un tensor y normalizarla
imagen_tensor = torch.tensor(imagen_df.values, dtype=torch.float32) / 255

# Asegurarse de que el tensor tiene el tamaño correcto
imagen_tensor = imagen_tensor.view(-1, 784)

# Evaluar el modelo (sin calcular gradientes)
modelo.eval()

# Pasar la imagen por el modelo
with torch.no_grad():
    prediccion = modelo(imagen_tensor)

# Mostrar el resultado
print("Predicción del modelo:", prediccion)















