"""
@author: Tomás Obregón
"""

import torch
import torch.nn as nn
import pandas as pd
import matplotlib.pyplot as plt
import torch.nn.functional as F

#%%
df = pd.read_csv('/Users/tomas/Desktop/Number/nmist_train_3.csv')

# Convertir los datos a tensores
train_labels = torch.tensor(df.iloc[:, 0].values, dtype=torch.long)
train_images = torch.tensor(df.iloc[:, 1:].values, dtype=torch.float32).reshape(-1, 1, 28, 28)/255


#%%

# Definir el modelo
class Model(nn.Module):
    def __init__(self):
        super().__init__()
        # conv layers
        self.conv1 = torch.nn.Conv2d(in_channels=1,        # 1 color channel (Grey)
                                     out_channels=3,       # How many outputs we're gonna have
                                     kernel_size=5, stride=1, padding=0, bias=True)
        
        self.conv2 = torch.nn.Conv2d(in_channels=3,        # 3 outputs from conv1
                                     out_channels=5,       # How many outputs we're gonna have
                                     kernel_size=5, stride=1, padding=0, bias=True)
        
        self.conv3 = torch.nn.Conv2d(in_channels=5,        # 5 outputs from conv2
                                     out_channels=10,      # How many outputs we're gonna have
                                     kernel_size=5, stride=1, padding=0, bias=True)
        self.maxpool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        
        # old model
        self.l1 = nn.Linear(10 * 8 * 8, 256)
        self.dropout1 = nn.Dropout(0.2)  
        self.l2       = nn.Linear(256, 128)   
        self.dropout2 = nn.Dropout(0.2)  
        self.l3 = nn.Linear(128, 10)   
        
    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))        
        x = self.maxpool(self.conv3(x))   
        
        x = x.view(x.size(0), -1)
        
        x = F.relu(self.l1(x))
        x = self.dropout1(x)  
        x = F.relu(self.l2(x))
        x = self.dropout2(x)  
        x = F.relu(self.l3(x))

        return x

# Crear el conjunto de datos y el DataLoader
train_dataset = torch.utils.data.TensorDataset(train_images, train_labels)
train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=100, shuffle=True)

# Instanciar el modelo, la función de pérdida y el optimizador
model = Model()
criterion = nn.CrossEntropyLoss()  # Esta es la función de pérdida correcta
optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

# Entrenamiento del modelo
num_epochs = 150
losses = []

for epoch in range(num_epochs):
    model.train()  # Poner el modelo en modo de entrenamiento
    running_loss = 0.0
    
    for inputs, labels in train_loader:
        optimizer.zero_grad()  # Limpiar los gradientes

        # Forward pass
        outputs = model(inputs)
        loss = criterion(outputs, labels)  # Calcular la pérdida correctamente
        
        # Backward pass y optimización
        loss.backward()
        optimizer.step()
        
        running_loss += loss.item()

    avg_loss = running_loss / len(train_loader)
    losses.append(avg_loss)
    
    # Imprimir la pérdida de la época actual
    print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {avg_loss:.4f}')

    plt.plot(figsize=[16,8])
    # Graficar la función de pérdida en tiempo real
    plt.clf()  # Limpiar la figura para la actualización en tiempo real
    plt.plot(losses, label='Loss', c='r')
    plt.xlabel('Epoch', fontsize=20)
    plt.ylabel('Loss', fontsize=20)
    plt.title('Loss over Epochs')
    plt.legend(fontsize=15)
    plt.grid(linestyle='--')
    plt.draw()
    plt.pause(0.1)  # Pausa para permitir la actualización de la gráfica

plt.show()  # Mostrar la gráfica final después del entrenamiento


#%%
# Save the model parameters
torch.save(model.state_dict(), 'model_parameters_conv.pth')


# # Use this to load it 
# model.load_state_dict(torch.load('model_parameters.pth'))

