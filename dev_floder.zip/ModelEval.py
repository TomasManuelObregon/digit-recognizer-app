"""
@author: Tomás Obregón
"""

import torch
import torch.nn as nn
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

#%%
class Model(nn.Module):
    def __init__(self):
        super().__init__()
        self.l1       = nn.Linear(784, 256)  
        # self.bn1      = nn.BatchNorm1d(256)
        self.dropout1 = nn.Dropout(0.2)  
      
        self.l2       = nn.Linear(256, 128)   
        # self.bn2      = nn.BatchNorm1d(128)
        self.dropout2 = nn.Dropout(0.2)  
        
        self.l3 = nn.Linear(128, 10)   

        
    def forward(self, x):
        x = nn.functional.relu(self.l1(x))
        x = self.dropout1(x)  
        x = nn.functional.relu(self.l2(x))
        x = self.dropout2(x)  
        x = nn.functional.relu(self.l3(x))

        return torch.softmax(x, dim=0)
    
model = Model()
model.load_state_dict(torch.load('model_parameters_2.pth'))

#%%
# Cargar los datos de prueba
test_df = pd.read_csv('/Users/tomas/Desktop/Number/mnist_test.csv')

# Convertir los datos de prueba a tensores
test_labels = torch.tensor(test_df.iloc[:, 0].values, dtype=torch.long)
test_images = torch.tensor(test_df.iloc[:, 1:].values, dtype=torch.float32)/255

# Crear el conjunto de datos y el DataLoader para los datos de prueba
test_dataset = torch.utils.data.TensorDataset(test_images, test_labels)
test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=100, shuffle=False)

# Poner el modelo en modo de evaluación
model.eval()

# Desactivar el cálculo de gradientes para la evaluación
with torch.no_grad():
    correct = 0
    total = 0
    
    for inputs, labels in test_loader:
        outputs = model(inputs)  # Realizar predicciones
        _, predicted = torch.max(outputs.data, 1)  # Obtener la clase con mayor probabilidad
        
        total += labels.size(0)
        correct += (predicted == labels).sum().item()  # Contar cuántas predicciones fueron correctas
    
    accuracy = 100 * correct / total
    print(f'Precisión del modelo en el conjunto de prueba: {accuracy:.2f}%')


 
#%%
imagen_df = np.loadtxt('/Users/tomas/Desktop/Number/num_valen.csv', delimiter=',')

# Convertir la imagen a un tensor y normalizarla
imagen_tensor = torch.tensor(imagen_df, dtype=torch.float32) / 255

# Asegurarse de que el tensor tiene el tamaño correcto
imagen_tensor = imagen_tensor.view(-1, 784)

# Evaluar el modelo (sin calcular gradientes)
model.eval()

# Pasar la imagen por el modelo
with torch.no_grad():
    prediccion = model(imagen_tensor)
    max_value, max_index = torch.max(prediccion, dim=0)


    
print("Predicción del modelo:", max_index)



