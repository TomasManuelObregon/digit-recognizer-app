"""
@author: Tomás Obregón
"""

import torch
import torch.nn as nn
import pandas as pd
import torch.nn.functional as F

#%%
class Model(nn.Module):
    def __init__(self):
        super().__init__()
        # conv layers
        self.conv1 = torch.nn.Conv2d(in_channels=1,        # 1 color channel (Grey)
                                     out_channels=3,       # How many outputs we're gonna have
                                     kernel_size=5, stride=1, padding=0, bias=True)
        
        self.conv2 = torch.nn.Conv2d(in_channels=3,        # 3 outputs from conv1
                                     out_channels=5,       # How many outputs we're gonna have
                                     kernel_size=5, stride=1, padding=0, bias=True)
        
        self.conv3 = torch.nn.Conv2d(in_channels=5,        # 5 outputs from conv2
                                     out_channels=10,      # How many outputs we're gonna have
                                     kernel_size=5, stride=1, padding=0, bias=True)
        self.maxpool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        
        # old model
        self.l1 = nn.Linear(10 * 8 * 8, 256)
        self.dropout1 = nn.Dropout(0.2)  
        self.l2       = nn.Linear(256, 128)   
        self.dropout2 = nn.Dropout(0.2)  
        self.l3 = nn.Linear(128, 10)   
        
    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))        
        x = self.maxpool(self.conv3(x))   
        
        x = x.view(x.size(0), -1)
        
        x = F.relu(self.l1(x))
        x = self.dropout1(x)  
        x = F.relu(self.l2(x))
        x = self.dropout2(x)  
        x = F.relu(self.l3(x))

        return x

    
model = Model()
model.load_state_dict(torch.load('model_parameters_conv.pth'))

#%%
# Cargar los datos de prueba
test_df = pd.read_csv('/Users/tomas/Desktop/Number/mnist_test.csv')

# Convertir los datos de prueba a tensores
test_labels = torch.tensor(test_df.iloc[:, 0].values, dtype=torch.long)
test_images = torch.tensor(test_df.iloc[:, 1:].values, dtype=torch.float32).reshape(-1, 1, 28, 28)/255

# Crear el conjunto de datos y el DataLoader para los datos de prueba
test_dataset = torch.utils.data.TensorDataset(test_images, test_labels)
test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=100, shuffle=False)

# Poner el modelo en modo de evaluación
model.eval()

# Desactivar el cálculo de gradientes para la evaluación
with torch.no_grad():
    correct = 0
    total = 0
    
    for inputs, labels in test_loader:
        outputs = model(inputs)  # Realizar predicciones
        _, predicted = torch.max(outputs.data, 1)  # Obtener la clase con mayor probabilidad
        
        total += labels.size(0)
        correct += (predicted == labels).sum().item()  # Contar cuántas predicciones fueron correctas
    
    accuracy = 100 * correct / total
    print(f'Precisión del modelo en el conjunto de prueba: {accuracy:.2f}%')


 
#%%
import numpy as np
imagen_df = np.loadtxt('/Users/tomas/Desktop/Number/num_valen.csv', delimiter=',')

# Convertir la imagen a un tensor y normalizarla
imagen_tensor = torch.tensor(imagen_df, dtype=torch.float32).reshape(-1, 1, 28, 28) / 255

# Evaluar el modelo (sin calcular gradientes)
model.eval()

# Pasar la imagen por el modelo
with torch.no_grad():
    prediccion = model(imagen_tensor)
    max_value, max_index = torch.max(prediccion, dim=1)


    
print("Predicción del modelo:", max_index)



